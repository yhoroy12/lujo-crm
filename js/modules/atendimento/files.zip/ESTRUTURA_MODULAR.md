# Estrutura Modular CSS - Módulo de Atendimento

## 📁 Hierarquia de Arquivos

```
css/
├── global.css                          # Estilos globais de todo o sistema
├── modulo-atendimento.css              # Estilos compartilhados do módulo
├── abas/
│   ├── aba-atendimento.css            # Aba principal: Atendimento (WhatsApp)
│   ├── aba-emails.css                  # Aba principal: E-mails
│   ├── aba-demandas.css                # Aba principal: Demandas (esqueleto)
│   └── aba-historico.css               # Aba principal: Histórico (esqueleto)
├── subabas/
│   ├── demandas-consulta.css          # Sub-aba: Consulta de Status
│   ├── demandas-recebidas.css         # Sub-aba: Demandas Recebidas
│   ├── demandas-minhas.css            # Sub-aba: Minhas Demandas
│   ├── demandas-encaminhadas.css      # Sub-aba: Meus Encaminhamentos
│   ├── historico-whatsapp.css         # Sub-aba: Histórico WhatsApp
│   └── historico-gmail.css            # Sub-aba: Histórico Gmail
└── componentes/
    ├── modais.css                      # Modais e popups
    └── utilitarios.css                 # Classes utilitárias

```

## 📋 Ordem de Importação

No seu HTML principal, importe os arquivos nesta ordem:

```html
<!-- 1. Global (base de tudo) -->
<link rel="stylesheet" href="css/global.css">

<!-- 2. Módulo (compartilhado entre abas) -->
<link rel="stylesheet" href="css/modulo-atendimento.css">

<!-- 3. Abas principais -->
<link rel="stylesheet" href="css/abas/aba-atendimento.css">
<link rel="stylesheet" href="css/abas/aba-emails.css">
<link rel="stylesheet" href="css/abas/aba-demandas.css">
<link rel="stylesheet" href="css/abas/aba-historico.css">

<!-- 4. Sub-abas -->
<link rel="stylesheet" href="css/subabas/demandas-consulta.css">
<link rel="stylesheet" href="css/subabas/demandas-recebidas.css">
<link rel="stylesheet" href="css/subabas/demandas-minhas.css">
<link rel="stylesheet" href="css/subabas/demandas-encaminhadas.css">
<link rel="stylesheet" href="css/subabas/historico-whatsapp.css">
<link rel="stylesheet" href="css/subabas/historico-gmail.css">

<!-- 5. Componentes -->
<link rel="stylesheet" href="css/componentes/modais.css">
<link rel="stylesheet" href="css/componentes/utilitarios.css">
```

## 🎯 Responsabilidades de Cada Arquivo

### global.css
- **O que contém:**
  - Variáveis CSS (cores, fontes, espaçamentos, z-index)
  - Reset CSS
  - Layout principal (app-layout, header, sidebar, footer)
  - Componentes globais (buttons, badges, forms, cards)
  - Utilitários básicos
  - Scrollbar global

- **Usado em:** Todos os módulos do sistema

### modulo-atendimento.css
- **O que contém:**
  - Variáveis específicas do módulo de atendimento
  - Container principal (.painel-atendimento)
  - Sistema de abas principais (.abas-container, .aba-btn)
  - Sistema de sub-abas (.sub-abas-demandas, .sub-aba-btn)
  - Cards e painéis genéricos
  - Estados vazios e de carregamento
  - Formulários básicos
  - Scrollbar customizado para o módulo

- **Usado em:** Todas as abas do módulo de atendimento

### aba-atendimento.css
- **O que contém:**
  - Grid de workspace (3 colunas: contexto, trabalho, suporte)
  - Coluna de contexto (.workspace-context)
    - Header do ticket
    - Informações do cliente
    - Checklist de identidade
    - Indicador SLA
  - Coluna principal (.workspace-main)
    - Barra de ações
    - Container de chat
    - Mensagens (bolhas)
    - Input de chat
  - Seções de suporte
    - Timeline
    - Ações rápidas
    - Performance

- **Usado em:** Apenas na aba "Atendimento"

### aba-emails.css
- **O que contém:**
  - Layout do painel de e-mails
  - Fila de atendimento (lateral)
  - Estado vazio (palco-vazio)
  - Card de atendimento ativo
    - Header do cliente
    - Timer de atendimento
    - Conteúdo formatado do e-mail
    - Área de resposta
    - Botões de ação

- **Usado em:** Apenas na aba "E-mails"

### aba-demandas.css
- **O que contém:**
  - Container principal de demandas
  - Estilos do esqueleto compartilhado entre sub-abas
  - Grid padrão (quando aplicável)
  - Navegação entre sub-abas

- **Usado em:** Aba "Demandas Externas" (estrutura base)

### aba-historico.css
- **O que contém:**
  - Container de histórico
  - Header com filtros
  - Sistema de busca
  - Estatísticas rápidas
  - Layout base para sub-abas de histórico

- **Usado em:** Aba "Histórico" (estrutura base)

### Sub-abas de Demandas

#### demandas-consulta.css
- Grid de 3 colunas (Filtros | Resultados | Detalhes)
- Formulário de busca
- Estados (vazio, carregando, sem resultados)
- Cards de resultados
- Painel de detalhes

#### demandas-recebidas.css
- Grid de 2 colunas (Lista | Detalhes)
- Fila de demandas recebidas
- Card de visualização
- Ações de aceitar/recusar

#### demandas-minhas.css
- Grid de 2 colunas (Lista | Detalhes)
- Lista de demandas em progresso
- Status específicos
- Formulário de resolução

#### demandas-encaminhadas.css
- Grid de 2 colunas (Lista | Detalhes)
- Lista de encaminhamentos
- Informações de destinatário
- Timeline de progresso

### Sub-abas de Histórico

#### historico-whatsapp.css
- Tabela de atendimentos WhatsApp
- Filtros específicos do canal
- Modal de detalhes
- Estatísticas

#### historico-gmail.css
- Tabela de atendimentos E-mail
- Filtros de status de e-mail
- Visualização de thread
- Métricas

### Componentes

#### modais.css
- Estrutura base de modais
- Overlay
- Animações de entrada/saída
- Variantes (pequeno, médio, grande)
- Modais específicos (encaminhamento, devolução, etc.)

#### utilitarios.css
- Classes de display (hidden, invisible, flex, grid)
- Classes de espaçamento (margin, padding helpers)
- Classes de texto (align, size, weight)
- Classes de cor
- Helpers de responsive

## 🔧 Convenções e Boas Práticas

### Nomenclatura
- **Módulo:** `.modulo-painel-atendimento` (prefixo para tudo)
- **Abas:** `.aba-atendimento`, `.aba-emails`, etc.
- **Sub-abas:** `.demandas-consulta`, `.historico-whatsapp`, etc.
- **Componentes:** `.painel-header`, `.card`, `.btn-primary`, etc.

### Especificidade
1. Sempre use o prefixo do módulo para evitar conflitos
2. Evite !important (exceto em utilitários .hidden)
3. Use classes, evite IDs para estilos
4. Mantenha especificidade baixa (máximo 3 níveis)

### Variáveis CSS
```css
/* Globais (em global.css) */
--color-primary
--color-success
--spacing-base
--radius

/* Módulo (em modulo-atendimento.css) */
--atendimento-bg
--workspace-gap
--status-novo
```

### Grid Layouts
```css
/* 3 colunas (Consulta de Demandas) */
.demandas-grid-3col {
  display: grid;
  grid-template-columns: 300px 1fr 350px;
  gap: var(--workspace-gap);
}

/* 2 colunas (Demandas Recebidas, Minhas) */
.demandas-grid-2col {
  display: grid;
  grid-template-columns: 400px 1fr;
  gap: var(--workspace-gap);
}
```

### Estados
```css
/* Sempre use classe .ativa para mostrar */
.aba-conteudo {
  display: none;
}

.aba-conteudo.ativa {
  display: flex;
}
```

## ⚠️ Pontos Críticos

### NÃO MODIFICAR sem testar:

1. **Grid do Workspace de Atendimento**
   ```css
   .atendimento-workspace {
     display: flex; /* NÃO mudar para grid */
     gap: 12px;
   }
   ```

2. **Container do Chat**
   ```css
   .chat-container {
     flex: 1 1 auto;
     min-height: 0; /* ESSENCIAL para scroll funcionar */
   }
   ```

3. **Border-radius das mensagens**
   ```css
   .msg.cliente {
     border-bottom-left-radius: 2px; /* Design específico */
   }
   
   .msg.atendente {
     border-bottom-right-radius: 2px; /* Design específico */
   }
   ```

4. **Z-index hierarchy**
   - Sempre use variáveis globais
   - Nunca ultrapasse --z-loading (2500)

## 📊 Mapeamento do CSS Original

### Seção 1: GLOBAL (linhas 19-48)
→ Vai para: `modulo-atendimento.css`

### Seção 2: LAYOUT PRINCIPAL (linhas 49-87)
→ Vai para: `aba-atendimento.css`

### Seção 3: ABAS E NAVEGAÇÃO (linhas 88-250)
→ Vai para: `modulo-atendimento.css`

### Seção 4: MÓDULO WHATSAPP (linhas 251-910)
→ Vai para: `aba-atendimento.css`

### Seção 5: MÓDULO E-MAIL (linhas 911-1307)
→ Vai para: `aba-emails.css`

### Seção 6: MÓDULO DEMANDAS (linhas 1308-2870)
→ Dividido em:
- `aba-demandas.css` (estrutura base)
- `demandas-consulta.css`
- `demandas-recebidas.css`
- `demandas-minhas.css`
- `demandas-encaminhadas.css`

### Seção 7: MÓDULO HISTÓRICO (linhas 2871-3283)
→ Dividido em:
- `aba-historico.css` (estrutura base)
- `historico-whatsapp.css`
- `historico-gmail.css`

### Seção 8: MODAIS E POPUPS (linhas 3284-3886)
→ Vai para: `componentes/modais.css`

### Seção 9: UTILITÁRIOS (linhas 3887-3945)
→ Vai para: `componentes/utilitarios.css`

### Seção 10: RESPONSIVIDADE (linhas 3946-4003)
→ Distribuído em cada arquivo respectivo

## 🚀 Como Usar

1. **Criar a estrutura de pastas**
2. **Copiar o conteúdo de cada arquivo** (fornecidos separadamente)
3. **Importar no HTML** na ordem especificada
4. **Testar cada aba** individualmente
5. **Ajustar variáveis** conforme necessário

## 🔍 Troubleshooting

### Problema: Grid não funciona
- Verifique se `.ativa` está presente
- Confirme que não há conflito de display
- Revise a ordem de importação dos CSS

### Problema: Chat não scrolla
- Verifique `min-height: 0` no `.chat-container`
- Confirme `flex: 1 1 auto` está presente
- Revise `overflow-y: auto` no `.chatbox`

### Problema: Estilos não aplicados
- Confirme ordem de importação
- Verifique especificidade das classes
- Revise se o prefixo `.modulo-painel-atendimento` está presente

## 📝 Notas Finais

- **Manutenção:** Cada aba é independente, facilitando updates
- **Performance:** Carregue apenas o CSS necessário (considere lazy loading)
- **Consistência:** Use sempre as variáveis CSS globais
- **Documentação:** Mantenha comentários nos arquivos
- **Versionamento:** Git-friendly, mudanças isoladas por arquivo

